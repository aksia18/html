/*Modal Layer Popup*/
$('.open-popup').click(function () {
    //    $('.modal').show()//
    $('.modal').fadeIn()
})
$('.close-popup').click(function () {
//    $('.modal').show()//
$('.modal').fadeOut()
})